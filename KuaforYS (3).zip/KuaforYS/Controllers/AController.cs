﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using KuaforYS.Data;
using KuaforYS.Models;
using System.Linq;
using System.Threading.Tasks;


namespace KuaforYS.Controllers
{
    public class AController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _context.A.ToListAsync());
        }

        public IActionResult Create()
        {
            ViewBag.AvailableTimes = new[] { 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 };
            ViewBag.EmpNames = _context.A.Select(a => a.EmpName).Distinct().ToList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(A model)
        {
            if (ModelState.IsValid)
            {
                // Check for Sunday
                if (model.SelectedDate.DayOfWeek == DayOfWeek.Sunday)
                {
                    TempData["Alert"] = "Appointments cannot be scheduled on Sundays.";
                    ViewBag.AvailableTimes = new[] { 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 };
                    ViewBag.EmpNames = _context.A.Select(a => a.EmpName).Distinct().ToList();
                    return View(model);
                }

                // Check for existing entry with the same EmpName, SelectedDate, and SelectedTime
                var existingEntry = await _context.A
                    .FirstOrDefaultAsync(a => a.EmpName == model.EmpName && a.SelectedDate.Date == model.SelectedDate.Date && a.SelectedTime == model.SelectedTime);

                if (existingEntry != null)
                {
                    TempData["Alert"] = "An entry for this employee at the selected time and date already exists.";
                    ViewBag.AvailableTimes = new[] { 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 };
                    ViewBag.EmpNames = _context.A.Select(a => a.EmpName).Distinct().ToList();
                    return View(model);
                }

                _context.Add(model);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            ViewBag.AvailableTimes = new[] { 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 };
            ViewBag.EmpNames = _context.A.Select(a => a.EmpName).Distinct().ToList();
            return View(model);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var a = await _context.A.FindAsync(id);
            if (a == null)
            {
                return NotFound();
            }

            ViewBag.AvailableTimes = new[] { 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 };
            ViewBag.EmpNames = _context.A.Select(a => a.EmpName).Distinct().ToList();
            return View(a);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, A model)
        {
            if (id != model.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Check for Sunday
                    if (model.SelectedDate.DayOfWeek == DayOfWeek.Sunday)
                    {
                        TempData["Alert"] = "Appointments cannot be scheduled on Sundays.";
                        ViewBag.AvailableTimes = new[] { 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 };
                        ViewBag.EmpNames = _context.A.Select(a => a.EmpName).Distinct().ToList();
                        return View(model);
                    }

                    // Check for existing entry with the same EmpName, SelectedDate, and SelectedTime (excluding current entry)
                    var existingEntry = await _context.A
                        .FirstOrDefaultAsync(a => a.EmpName == model.EmpName && a.SelectedDate.Date == model.SelectedDate.Date && a.SelectedTime == model.SelectedTime && a.Id != model.Id);

                    if (existingEntry != null)
                    {
                        TempData["Alert"] = "An entry for this employee at the selected time and date already exists.";
                        ViewBag.AvailableTimes = new[] { 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 };
                        ViewBag.EmpNames = _context.A.Select(a => a.EmpName).Distinct().ToList();
                        return View(model);
                    }

                    _context.Update(model);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AExists(model.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            ViewBag.AvailableTimes = new[] { 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 };
            ViewBag.EmpNames = _context.A.Select(a => a.EmpName).Distinct().ToList();
            return View(model);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var a = await _context.A.FirstOrDefaultAsync(m => m.Id == id);
            if (a == null)
            {
                return NotFound();
            }

            return View(a);
        }



        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var a = await _context.A.FirstOrDefaultAsync(m => m.Id == id);
            if (a == null)
            {
                return NotFound();
            }

            return View(a);
        }

        private bool AExists(int id)
        {
            return _context.A.Any(e => e.Id == id);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var appointment = _context.A.Find(id);
            if (appointment == null)
            {
                return NotFound();
            }

            _context.A.Remove(appointment);
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

    }
}
