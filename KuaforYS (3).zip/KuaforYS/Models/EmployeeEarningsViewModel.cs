﻿public class EmployeeEarningsViewModel
{
    public string EmployeeName { get; set; }
    public decimal TotalEarnings { get; set; }
}
