
using KuaforYS.Data;
using KuaforYS.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using NuGet.Packaging;
using System;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

// Veritaban? yap?land?rmas?
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));

// Geli?tirici sayfa hatalar?n? etkinle?tirin
builder.Services.AddDatabaseDeveloperPageExceptionFilter();

// Kimlik do?rulama hizmetleri
builder.Services.AddDefaultIdentity<IdentityUser>(options => options.SignIn.RequireConfirmedAccount = true)
    .AddEntityFrameworkStores<ApplicationDbContext>();

// Razor Pages ve MVC yap?land?rmas?
builder.Services.AddControllersWithViews();

// **Session** yap?land?rmas?
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Session s�resi
    options.Cookie.HttpOnly = true; // G�venlik i�in HTTPOnly
    options.Cookie.IsEssential = true; // �erezlerin gerekli oldu?unu belirtin
});

// **HttpContextAccessor** yap?land?rmas?
builder.Services.AddHttpContextAccessor();

var app = builder.Build();

// Veritaban? Seed ??lemi
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    if (!context.Users.Any(u => u.Email == "G221210086@sakarya.edu.tr"))
    {
        context.Users.Add(new User
        {
            Name = "Admin User",
            Email = "G221210086@sakarya.edu.tr",
            Password = "sau",
            Role = "Admin"
        });
        context.SaveChanges();
    }

}

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseMigrationsEndPoint();
}
else
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}



app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// **Session Middleware** kullan?m?
app.UseSession(); // Middleware s?ras? �nemli: UseRouting()'den �nce olmal?!

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.MapRazorPages();

app.Run();
