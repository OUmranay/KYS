﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using KuaforYS.Data;
using KuaforYS.Models;
using Microsoft.AspNetCore.Mvc.Rendering;


namespace KuaforYS.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EmployeesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Employees
        public async Task<IActionResult> Index()
        {
            return View(await _context.Employees.ToListAsync());
        }

        // GET: Employees/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees
                .FirstOrDefaultAsync(m => m.Id == id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        

       
        public IActionResult Create()
        {
            // Fetch the list of employees from the database and project them into a list with Id and FullName
            var employees = _context.Employees.Select(e => new
            {
                e.Id,
                FullName = e.FirstName + " " + e.LastName // Concatenate FirstName and LastName to create FullName
            }).ToList();

            // Pass the list of employees as a SelectList to the view
            ViewBag.EmpNames = new SelectList(employees, "Id", "FullName");

            // Optionally, populate available times (if necessary)
            ViewBag.AvailableTimes = new List<int> { 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 }; // Sample times

            return View();
        }


        // POST: Employees/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Employee employee, List<string> SelectedDepartments)
        {
            employee.CreatedById = "Admin";
            employee.CreatedOn = DateTime.Now;

            if (ModelState.IsValid)
            {
                employee.Departments = SelectedDepartments; // Seçilen departmanları modele ata
                _context.Add(employee);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            // Validasyon hatası durumunda tekrar ViewBag.Departments set edilmesi gerekiyor
            ViewBag.Departments = new List<string> { "Styling", "Haircuts", "Colour", "Extensions", "Treatments", "Conditioning" };
            return View(employee);
        }



        // GET: Employees/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }

            // List departments in the dropdown
            ViewBag.Departments = new List<string> { "Styling", "Haircuts", "Colour", "Extensions", "Treatments", "Conditioning" };
            return View(employee);
        }

        // POST: Employees/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Employee employee, List<string> SelectedDepartments)
        {
            if (id != employee.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    employee.Departments = SelectedDepartments; // Seçilen departmanları güncelle
                    _context.Update(employee);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeeExists(employee.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            // Validasyon hatası durumunda tekrar ViewBag.Departments set edilmesi gerekiyor
            ViewBag.Departments = new List<string> { "Styling", "Haircuts", "Colour", "Extensions", "Treatments", "Conditioning" };
            return View(employee);
        }

        // GET: Employees/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees
                .FirstOrDefaultAsync(m => m.Id == id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // POST: Employees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee != null)
            {
                _context.Employees.Remove(employee);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EmployeeExists(int id)
        {
            return _context.Employees.Any(e => e.Id == id);
        }

        // New method: List employees based on department


        public async Task<IActionResult> ListByDepartment(string department)
        {
            // If no department is provided, return a "not found" page
            if (string.IsNullOrEmpty(department))
            {
                return NotFound();
            }

            // Fetch employees based on the department from the database
            var employees = await _context.Employees
                                          .Where(e => e.Departments.Contains(department))
                                          .ToListAsync();

            // If no employees are found, set a message in ViewBag
            if (employees == null || !employees.Any())
            {
                ViewBag.Message = "No employees found in this department.";
            }

            // Pass the list of employees to the view through ViewBag
            ViewBag.Employees = employees;
            ViewBag.SelectedDepartment = department;

            // Return the view with the list of employees
            return View();
        }

       
        // GET: Employees/GetEmployeesByDepartment
        [HttpGet]
        public async Task<IActionResult> GetEmployeesByDepartment(string department)
        {
            if (string.IsNullOrEmpty(department))
            {
                return Json(new { message = "Department cannot be empty" });
            }

            var employees = await _context.Employees
                                          .Where(e => e.Departments.Contains(department))
                                          .Select(e => new { e.Id, e.FullName }) // İhtiyaç duyduğun veri
                                          .ToListAsync();

            return Json(employees);
        }


        public async Task<IActionResult> DailyEarnings()
        {
            DateTime date = DateTime.Now.Date; // Bugünün tarihini kullan

            var appointments = await _context.A
                                              .Where(a => a.SelectedDate.Date == date)
                                              .ToListAsync();

            var employees = await _context.Employees.ToListAsync();
            var earnings = new List<dynamic>();

            foreach (var employee in employees)
            {
                decimal dailyEarnings = 0;

                var employeeAppointments = appointments.Where(a => a.EmpName == employee.FullName).ToList();

                foreach (var appointment in employeeAppointments)
                {
                    switch (appointment.Department)
                    {
                        case "Styling":
                            dailyEarnings += 25;
                            break;
                        case "Haircuts":
                            dailyEarnings += 65;
                            break;
                        case "Colour":
                            dailyEarnings += 185;
                            break;
                        case "Extensions":
                            dailyEarnings += 115;
                            break;
                        case "Treatments":
                            dailyEarnings += 35;
                            break;
                    }
                }

                earnings.Add(new { EmployeeName = employee.FullName, DailyEarnings = dailyEarnings });
            }

            ViewBag.Date = date;
            return View(earnings);
        }


    }
}
