﻿using KuaforYS.Data;
using Microsoft.AspNetCore.Mvc;

public class AppointmentController : Controller
{
    private readonly ApplicationDbContext _context;

    public AppointmentController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpPost]
    public JsonResult GetEmployeesByDepartment(string department)
    {
        // Seçilen departmana göre çalışanları filtrele
        var employees = _context.Employees
            .Where(e => e.Departments.Contains(department))
            .Select(e => new { e.Id, e.FullName })
            .ToList();

        return Json(employees);
    }
}
