﻿using System.ComponentModel.DataAnnotations;
namespace KuaforYS.Models
{
    public class Randevu
    {
       
        [Required(ErrorMessage = "Can't be left empty")]

        public string Name { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]


        public int PhoneNumber { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public DateTime Time{ get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public string Hour { get; set; }
       

        public string Department { get; set; }


        public string Emp { get; set; }
       


        public int Id { get; set; }

    }


}
