﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace KuaforYS.Data.Migrations
{
    /// <inheritdoc />
    public partial class up : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "EmployeeId",
                table: "Rendezvous");

            migrationBuilder.AddColumn<string>(
                name: "EmployeeName",
                table: "Rendezvous",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Name",
                table: "Rendezvous",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "EmployeeName",
                table: "Rendezvous");

            migrationBuilder.DropColumn(
                name: "Name",
                table: "Rendezvous");

            migrationBuilder.AddColumn<int>(
                name: "EmployeeId",
                table: "Rendezvous",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
