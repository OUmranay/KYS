﻿namespace KuaforYS.Models
{
    public class HairStyle
    {
    }
}
