﻿using System.ComponentModel.DataAnnotations;
namespace KuaforYS.Models
{
    public class Employee : UserActivity
    {
        [Required(ErrorMessage = "Can't be left empty")]
        public string EmpNo { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public string FirstName { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public string MiddleName { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public string LastName { get; set; }
        public string FullName => $"{FirstName}{MiddleName}{LastName}";
        [Required(ErrorMessage = "Can't be left empty")]

        public int PhoneNumber { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public string EmailAddress { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public DateTime DateOfBirth { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public string Address { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public List<string> Departments { get; set; } = new List<string>();

        public int Id { get; set; }

        // Yeni özellikler
        public List<string> WorkingDays { get; set; } = new List<string> { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" }; // Çalışma günleri
        public List<int> WorkingHours { get; set; } = new List<int> { 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 }; // Çalışma saatleri
    }


}
