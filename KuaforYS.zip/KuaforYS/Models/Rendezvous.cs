﻿using System.ComponentModel.DataAnnotations;

namespace KuaforYS.Models
{
    public class Rendezvous
    {
        public string Name { get; set; } // Saç kesimi, bakım, vb.
        [Required(ErrorMessage = "Can't be left empty")]


        public string Department { get; set; } // Saç kesimi, bakım, vb.
        public int PhoneNumber { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public DateTime Date { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public string EmployeeName { get; set; }

        public bool IsApproved { get; set; } = false; // Admin onayı

        public int Id { get; set; }
    }
}
