﻿
using KuaforYS.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace KuaforYS.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        internal IEnumerable<object> Appointments;

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Employee> Employees { get; set; }

        public DbSet<Randevu> Randevular { get; set; }

        public DbSet<KuaforYS.Models.A> A { get; set; } = default!;






        public DbSet<User> Users { get; set; }


        
 
       

    }
}
