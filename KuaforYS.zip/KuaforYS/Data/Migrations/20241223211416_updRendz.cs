﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace KuaforYS.Data.Migrations
{
    /// <inheritdoc />
    public partial class updRendz : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "PhoneNumber",
                table: "Rendezvous",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<string>(
                name: "Time",
                table: "Rendezvous",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "UserEmail",
                table: "Rendezvous",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Time",
                table: "Rendezvous");

            migrationBuilder.DropColumn(
                name: "UserEmail",
                table: "Rendezvous");

            migrationBuilder.AlterColumn<int>(
                name: "PhoneNumber",
                table: "Rendezvous",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");
        }
    }
}
