﻿using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.Linq;
using System.Collections.Generic;
using System;

public class HairStyleSuggestionService
{
    private readonly HttpClient _client;
    private readonly string _apiKey;

    public HairStyleSuggestionService(string apiKey)
    {
        _client = new HttpClient();
        _apiKey = apiKey;
    }

    public async Task<string> GetHairStyleSuggestions(string imagePath)
    {
        var imageBytes = System.IO.File.ReadAllBytes(imagePath);
        var base64Image = Convert.ToBase64String(imageBytes);

        var jsonContent = new JObject
        {
            ["inputs"] = base64Image,
            ["parameters"] = new JObject
            {
                ["candidate_labels"] = new JArray("curly hair", "straight hair", "blonde hair", "brown hair", "short hair", "long hair")
            }
        };

        var requestMessage = new HttpRequestMessage(HttpMethod.Post, "https://api-inference.huggingface.co/models/openai/clip-vit-base-patch32");
        requestMessage.Headers.Add("Authorization", $"Bearer {_apiKey}");
        requestMessage.Content = new StringContent(jsonContent.ToString(), System.Text.Encoding.UTF8, "application/json");

        try
        {
            var response = await _client.SendAsync(requestMessage);
            var jsonResponse = await response.Content.ReadAsStringAsync();

            var jsonArray = JArray.Parse(jsonResponse);
            var results = jsonArray.ToObject<List<LabelResult>>();

            // En yüksek skora sahip etiketi bul ve öneriyi oluştur
            var bestMatch = results.OrderByDescending(r => r.Score).FirstOrDefault();

            if (bestMatch != null)
            {
                return GenerateSuggestion(bestMatch.Label);
            }
            else
            {
                return "No suitable hair style suggestion could be determined from the analysis.";
            }
        }
        catch (HttpRequestException e)
        {
            return $"Request error: {e.Message}";
        }
    }

    private string GenerateSuggestion(string bestMatch)
    {
        var suggestions = new Dictionary<string, string>
        {
            { "curly hair", "Based on the analysis, a curly hairstyle would give you a lively and vibrant look." },
            { "straight hair", "Straight hair would provide you with a sleek and elegant appearance." },
            { "blonde hair", "Blonde hair could add a touch of brightness and warmth to your overall look." },
            { "brown hair", "Brown hair would offer a natural and classic look that suits any occasion." },
            { "short hair", "Short hair could give you a modern and dynamic style." },
            { "long hair", "Long hair would provide a versatile and feminine look." }
        };

        if (suggestions.ContainsKey(bestMatch))
        {
            return suggestions[bestMatch];
        }
        else
        {
            return "A unique hairstyle suggestion is recommended based on your analysis.";
        }
    }
}

public class LabelResult
{
    public double Score { get; set; }
    public string Label { get; set; }
}
