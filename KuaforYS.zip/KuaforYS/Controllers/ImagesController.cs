﻿using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Threading.Tasks;

public class ImagesController : Controller
{
    private readonly HairStyleSuggestionService _hairStyleSuggestionService;

    public ImagesController(HairStyleSuggestionService hairStyleSuggestionService)
    {
        _hairStyleSuggestionService = hairStyleSuggestionService;
    }

    [HttpGet]
    public IActionResult Upload()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Upload(IFormFile file)
    {
        if (file == null || file.Length == 0)
        {
            return BadRequest("No file uploaded.");
        }

        var directoryPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/images");
        if (!Directory.Exists(directoryPath))
        {
            Directory.CreateDirectory(directoryPath);
        }

        var filePath = Path.Combine(directoryPath, file.FileName);
        using (var stream = new FileStream(filePath, FileMode.Create))
        {
            await file.CopyToAsync(stream);
        }

        var analysisResult = await _hairStyleSuggestionService.GetHairStyleSuggestions(filePath);
        ViewBag.AnalysisResult = analysisResult;
        return View("Result");
    }
}
