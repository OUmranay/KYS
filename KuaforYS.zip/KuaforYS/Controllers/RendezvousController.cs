﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using KuaforYS.Data;
using KuaforYS.Models;

namespace KuaforYS.Controllers
{
    public class RendezvousController : Controller
    {
        private readonly ApplicationDbContext _context;

        public RendezvousController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Rendezvous
        public async Task<IActionResult> Index()
        {
            return View(await _context.Rendezvous.ToListAsync());
        }

        // GET: Rendezvous/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rendezvous = await _context.Rendezvous
                .FirstOrDefaultAsync(m => m.Id == id);
            if (rendezvous == null)
            {
                return NotFound();
            }

            return View(rendezvous);
        }

        // GET: Rendezvous/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Rendezvous/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Name,Department,PhoneNumber,Date,EmployeeName,IsApproved,Id")] Rendezvous rendezvous)
        {
            if (ModelState.IsValid)
            {
                _context.Add(rendezvous);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(rendezvous);
        }

        // GET: Rendezvous/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rendezvous = await _context.Rendezvous.FindAsync(id);
            if (rendezvous == null)
            {
                return NotFound();
            }
            return View(rendezvous);
        }

        // POST: Rendezvous/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Name,Department,PhoneNumber,Date,EmployeeName,IsApproved,Id")] Rendezvous rendezvous)
        {
            if (id != rendezvous.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(rendezvous);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RendezvousExists(rendezvous.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(rendezvous);
        }

        // GET: Rendezvous/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rendezvous = await _context.Rendezvous
                .FirstOrDefaultAsync(m => m.Id == id);
            if (rendezvous == null)
            {
                return NotFound();
            }

            return View(rendezvous);
        }

        // POST: Rendezvous/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var rendezvous = await _context.Rendezvous.FindAsync(id);
            if (rendezvous != null)
            {
                _context.Rendezvous.Remove(rendezvous);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }


        // GET: Departman bazlı çalışan listeleme (AJAX)
        [HttpGet]
        public IActionResult GetEmployeesByDepartment(string department)
        {
            if (string.IsNullOrEmpty(department))
            {
                return Json(new List<Employee>());
            }

            var employees = _context.Employees
                .Where(e => e.Departments.Contains(department))
                .Select(e => new { e.Id, e.FullName })
                .ToList();

            return Json(employees);
        }
        private bool RendezvousExists(int id)
        {
            return _context.Rendezvous.Any(e => e.Id == id);
        }
    }
}
