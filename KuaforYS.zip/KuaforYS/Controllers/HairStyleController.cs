﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

public class HairStyleController : Controller
{
    private readonly HttpClient _httpClient;

    public HairStyleController(IHttpClientFactory httpClientFactory)
    {
        _httpClient = httpClientFactory.CreateClient();
    }

    [HttpPost]
    public async Task<IActionResult> SuggestHairStyle(IFormFile imageFile)
    {
        if (imageFile == null || imageFile.Length == 0)
        {
            return BadRequest("Geçerli bir resim yükleyin.");
        }

        // Resmi byte dizisine dönüştür
        byte[] imageData;
        using (var ms = new MemoryStream())
        {
            await imageFile.CopyToAsync(ms);
            imageData = ms.ToArray();
        }

        // Hugging Face API ayarları
        string apiUrl = "https://api-inference.huggingface.co/models/akhaliq/HairCLIP";
        string token = "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";

        var requestMessage = new HttpRequestMessage(HttpMethod.Post, apiUrl);
        requestMessage.Headers.Add("Authorization", $"Bearer {token}");
        requestMessage.Content = new ByteArrayContent(imageData);
        requestMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");

        // API'ye istek gönder
        var response = await _httpClient.SendAsync(requestMessage);

        if (!response.IsSuccessStatusCode)
        {
            return BadRequest($"Yapay zeka servisi hatası: {response.ReasonPhrase}");
        }

        var result = await response.Content.ReadAsStringAsync();
        var jsonResult = JsonSerializer.Deserialize<object>(result);

        return View("Result", jsonResult); // Öneriyi bir view'e gönder
    }
}
