﻿using System.ComponentModel.DataAnnotations;
namespace KuaforYonetimSistemi_3.Models
{
    public class Employee : UserActivity
{
        [Required(ErrorMessage = "Can't be left empty")]
        public string EmpNo { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public string FirstName { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public string MiddleName { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public string LastName { get; set; }
        public string FullName => $"{FirstName}{MiddleName}{LastName}";
        [Required(ErrorMessage = "Can't be left empty")]

        public int PhoneNumber { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public string EmailAddress { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public DateTime DateOfBirth { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public string Address { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public List<string> Departments { get; set; } = new List<string>();

        public int Id { get; set; }

    }
}
