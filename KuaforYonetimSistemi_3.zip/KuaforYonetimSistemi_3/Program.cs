﻿using KuaforYonetimSistemi_3.Data;
using KuaforYonetimSistemi_3.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

// Veritabanı yapılandırması
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));

// Geliştirici sayfa hatalarını etkinleştirin
builder.Services.AddDatabaseDeveloperPageExceptionFilter();

// Kimlik doğrulama hizmetleri
builder.Services.AddDefaultIdentity<IdentityUser>(options => options.SignIn.RequireConfirmedAccount = true)
    .AddEntityFrameworkStores<ApplicationDbContext>();

// Razor Pages ve MVC yapılandırması
builder.Services.AddControllersWithViews();

// **Session** yapılandırması
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Session süresi
    options.Cookie.HttpOnly = true; // Güvenlik için HTTPOnly
    options.Cookie.IsEssential = true; // Çerezlerin gerekli olduğunu belirtin
});

// **HttpContextAccessor** yapılandırması
builder.Services.AddHttpContextAccessor();

var app = builder.Build();

// Veritabanı Seed İşlemi
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

    if (!context.Users.Any(u => u.Email == "G221210086@sakarya.edu.tr"))
    {
        context.Users.Add(new User
        {
            Name = "Admin User",
            Email = "G221210086@sakarya.edu.tr",
            Password = "sau",
            Role = "Admin"
        });
        context.SaveChanges();
    }
}

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseMigrationsEndPoint();
}
else
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// **Session Middleware** kullanımı
app.UseSession(); // Middleware sırası önemli: UseRouting()'den önce olmalı!

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.MapRazorPages();

app.Run();
