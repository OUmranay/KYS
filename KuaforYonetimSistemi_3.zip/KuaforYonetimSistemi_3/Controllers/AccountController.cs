﻿using KuaforYonetimSistemi_3.Data;
using KuaforYonetimSistemi_3.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages.Manage;
using System;


namespace YourProjectName.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccountController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public IActionResult SignUp(User user)
        {
            if (ModelState.IsValid)
            {
                // Kullanıcıyı veritabanına ekle
                _context.Users.Add(user);
                _context.SaveChanges();

                // Başarılı mesajı TempData'ya ekle
                TempData["Message"] = "Sign up successful! You can now log in.";
                return Redirect("/#login");
            }

            TempData["Message"] = "Sign up failed. Please try again.";
            return Redirect("/#login");
        }

        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            var user = _context.Users.FirstOrDefault(u => u.Email == email && u.Password == password);
            if (user != null)
            {
                // Başarılı giriş mesajı
                HttpContext.Session.SetString("UserName", user.Name);
                HttpContext.Session.SetString("UserRole", user.Role);

                TempData["Message"] = $"Welcome back, {user.Name}!";
                return Redirect("/#login");
            }
            TempData["Message"] = "Invalid email or password.";
            return Redirect("/#login");
        }


        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return Redirect("/");
        }
    }
}


