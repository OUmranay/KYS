﻿
using System.ComponentModel.DataAnnotations;
namespace KuaforYS.Models
{

    public class User
    {
        [Required(ErrorMessage = "Can't be left empty")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public string Email { get; set; }
        [Required(ErrorMessage = "Can't be left empty")]

        public string Password { get; set; }

        public int Id { get; set; }
        public string Role { get; set; } = "Customer"; // "Admin" veya "User"
    }
}
